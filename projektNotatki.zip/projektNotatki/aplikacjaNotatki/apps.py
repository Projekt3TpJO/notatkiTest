from django.apps import AppConfig


class AplikacjanotatkiConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'aplikacjaNotatki'
